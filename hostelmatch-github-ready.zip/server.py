#!/usr/bin/env python3
"""
HostelMatch – Python Backend Server
Zero-dependency Python 3 HTTP server providing REST API and static file serving.
"""

import http.server
import socketserver
import json
import os
import re
from urllib.parse import urlparse

PORT = int(os.environ.get("PORT", 3000))
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, "data", "hostels.json")

def read_hostels():
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print("Error reading hostels.json:", e)
    return []

def write_hostels(data):
    os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

class HostelMatchHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=BASE_DIR, **kwargs)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/api/hostels":
            hostels = read_hostels()
            payload = json.dumps({"results": hostels, "count": len(hostels)}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return

        if path == "/admin" or path == "/":
            self.path = "/index.html"

        super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/hostels":
            content_length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_length).decode("utf-8")
            new_item = json.loads(body)
            new_item["id"] = int(os.urandom(4).hex(), 16)
            hostels = read_hostels()
            hostels.insert(0, new_item)
            write_hostels(hostels)

            payload = json.dumps({"success": True, "hostel": new_item}).encode("utf-8")
            self.send_response(201)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(payload)
            return

        self.send_error(404, "Not Found")

print(f"🏠 HostelMatch Python Server running at: http://localhost:{PORT}")
print(f"🔍 Main Discovery App: http://localhost:{PORT}/")
print(f"⚙️ Admin Dashboard:    http://localhost:{PORT}/admin")

with socketserver.TCPServer(("", PORT), HostelMatchHandler) as httpd:
    httpd.serve_forever()
