/**
 * HostelMatch – Production-Ready Backend Server
 * Zero-dependency pure Node.js HTTP server providing static file hosting and RESTful API endpoints.
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data', 'hostels.json');
const PUBLIC_DIR = __dirname;

// MIME Type Registry
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.webp': 'image/webp'
};

// Helper to read and write database file
function readHostelsData() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const content = fs.readFileSync(DATA_FILE, 'utf8');
      return JSON.parse(content);
    }
  } catch (err) {
    console.error('Error reading hostels.json:', err);
  }
  return [];
}

function writeHostelsData(data) {
  try {
    const dir = path.dirname(DATA_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (err) {
    console.error('Error writing hostels.json:', err);
    return false;
  }
}

// Comprehensive Engineering Colleges registry
const COLLEGES = [
  // --- Zone 1: Premier & Central Institutes ---
  { id: "iit_bombay", name: "IIT Bombay (Powai)", shortName: "IIT Bombay", zone: "Premier Institutes", lat: 19.1334, lng: 72.9133, city: "Mumbai", area: "Powai, Mumbai" },
  { id: "vjti_matunga", name: "VJTI - Veermata Jijabai Technological Institute (Matunga)", shortName: "VJTI Matunga", zone: "Premier Institutes", lat: 19.0222, lng: 72.8561, city: "Mumbai", area: "Matunga, Mumbai" },
  { id: "ict_mumbai", name: "ICT Mumbai - Institute of Chemical Technology (Matunga)", shortName: "ICT Mumbai", zone: "Premier Institutes", lat: 19.0238, lng: 72.8586, city: "Mumbai", area: "Matunga, Mumbai" },
  { id: "mu_kalina", name: "University of Mumbai - Tech & Sciences Campus (Kalina)", shortName: "MU Kalina", zone: "Premier Institutes", lat: 19.0748, lng: 72.8682, city: "Mumbai", area: "Kalina, Santacruz East" },

  // --- Zone 2: Western Suburbs ---
  { id: "spit_andheri", name: "SPIT - Sardar Patel Institute of Technology (Andheri West)", shortName: "SPIT Andheri", zone: "Western Suburbs", lat: 19.1232, lng: 72.8360, city: "Mumbai", area: "Andheri West, Mumbai" },
  { id: "spce_andheri", name: "SPCE - Sardar Patel College of Engineering (Andheri West)", shortName: "SPCE Andheri", zone: "Western Suburbs", lat: 19.1238, lng: 72.8364, city: "Mumbai", area: "Andheri West, Mumbai" },
  { id: "djsanghvi", name: "D.J. Sanghvi College of Engineering (Vile Parle West)", shortName: "DJ Sanghvi", zone: "Western Suburbs", lat: 19.1075, lng: 72.8372, city: "Mumbai", area: "Vile Parle West, Mumbai" },
  { id: "nmims_mpstme", name: "NMIMS MPSTME - Mukesh Patel School of Technology (Vile Parle)", shortName: "MPSTME NMIMS", zone: "Western Suburbs", lat: 19.1030, lng: 72.8360, city: "Mumbai", area: "Vile Parle West, Mumbai" },
  { id: "tsec_bandra", name: "Thadomal Shahani Engineering College - TSEC (Bandra West)", shortName: "TSEC Bandra", zone: "Western Suburbs", lat: 19.0645, lng: 72.8358, city: "Mumbai", area: "Bandra West, Mumbai" },
  { id: "crce_bandra", name: "Fr. CRCE - Fr. Conceicao Rodrigues College of Engg (Bandra Bandstand)", shortName: "Fr. Agnel Bandra", zone: "Western Suburbs", lat: 19.0441, lng: 72.8207, city: "Mumbai", area: "Bandra West, Mumbai" },
  { id: "rizvi_bandra", name: "Rizvi College of Engineering (Bandra West)", shortName: "Rizvi Engg Bandra", zone: "Western Suburbs", lat: 19.0680, lng: 72.8270, city: "Mumbai", area: "Bandra West, Mumbai" },
  { id: "rgit_versova", name: "RGIT - Rajiv Gandhi Institute of Technology (Versova, Andheri West)", shortName: "RGIT Versova", zone: "Western Suburbs", lat: 19.1350, lng: 72.8180, city: "Mumbai", area: "Andheri West, Mumbai" },
  { id: "umit_sndt_juhu", name: "UMIT - Usha Mittal Institute of Technology (SNDT Juhu)", shortName: "UMIT Juhu (Women)", zone: "Western Suburbs", lat: 19.0965, lng: 72.8300, city: "Mumbai", area: "Juhu, Mumbai" },

  // --- Zone 3: Northern Suburbs ---
  { id: "tcet_kandivali", name: "TCET - Thakur College of Engineering & Technology (Kandivali East)", shortName: "TCET Kandivali", zone: "Northern Suburbs", lat: 19.2060, lng: 72.8735, city: "Mumbai", area: "Kandivali East, Mumbai" },
  { id: "atharva_malad", name: "Atharva College of Engineering (Malad West)", shortName: "Atharva Malad", zone: "Northern Suburbs", lat: 19.1960, lng: 72.8290, city: "Mumbai", area: "Malad West, Mumbai" },
  { id: "sfit_borivali", name: "SFIT - St. Francis Institute of Technology (Borivali West)", shortName: "SFIT Borivali", zone: "Northern Suburbs", lat: 19.2450, lng: 72.8540, city: "Mumbai", area: "Borivali West, Mumbai" },

  // --- Zone 4: Central & Eastern Suburbs ---
  { id: "kjsce_vidyavihar", name: "K.J. Somaiya College of Engineering - KJSCE (Vidyavihar)", shortName: "K.J. Somaiya Vidyavihar", zone: "Central & Eastern Suburbs", lat: 19.0726, lng: 72.8996, city: "Mumbai", area: "Vidyavihar East, Mumbai" },
  { id: "kjsieit_sion", name: "K.J. Somaiya Institute of Engineering & IT - KJSIEIT (Sion)", shortName: "Somaiya Sion", zone: "Central & Eastern Suburbs", lat: 19.0463, lng: 72.8716, city: "Mumbai", area: "Sion, Mumbai" },
  { id: "vesit_chembur", name: "VESIT - Vivekanand Education Society's Institute of Tech (Chembur)", shortName: "VESIT Chembur", zone: "Central & Eastern Suburbs", lat: 19.0450, lng: 72.8890, city: "Mumbai", area: "Chembur, Mumbai" },
  { id: "sakec_chembur", name: "Shah & Anchor Kutchhi Engineering College - SAKEC (Chembur)", shortName: "SAKEC Chembur", zone: "Central & Eastern Suburbs", lat: 19.0538, lng: 72.9126, city: "Mumbai", area: "Chembur, Mumbai" },
  { id: "vit_wadala", name: "VIT - Vidyalankar Institute of Technology (Wadala East)", shortName: "VIT Wadala", zone: "Central & Eastern Suburbs", lat: 19.0218, lng: 72.8710, city: "Mumbai", area: "Wadala East, Mumbai" },
  { id: "dbit_kurla", name: "DBIT - Don Bosco Institute of Technology (Kurla West)", shortName: "DBIT Kurla", zone: "Central & Eastern Suburbs", lat: 19.0805, lng: 72.8885, city: "Mumbai", area: "Kurla West, Mumbai" },

  // --- Zone 5: South Mumbai ---
  { id: "saboo_siddik", name: "M.H. Saboo Siddik College of Engineering (Byculla)", shortName: "Saboo Siddik Byculla", zone: "South Mumbai", lat: 18.9680, lng: 72.8295, city: "Mumbai", area: "Byculla, Mumbai" },

  // --- Zone 6: Navi Mumbai Hub ---
  { id: "fcrit_vashi", name: "FCRIT - Fr. C. Rodrigues Institute of Technology (Vashi)", shortName: "FCRIT Vashi", zone: "Navi Mumbai Hub", lat: 19.0770, lng: 72.9980, city: "Navi Mumbai", area: "Vashi, Navi Mumbai" },
  { id: "sies_nerul", name: "SIES Graduate School of Technology (Nerul)", shortName: "SIES GST Nerul", zone: "Navi Mumbai Hub", lat: 19.0370, lng: 73.0180, city: "Navi Mumbai", area: "Nerul, Navi Mumbai" },
  { id: "rait_nerul", name: "RAIT - Ramrao Adik Institute of Tech / D.Y. Patil (Nerul)", shortName: "RAIT D.Y. Patil Nerul", zone: "Navi Mumbai Hub", lat: 19.0435, lng: 73.0245, city: "Navi Mumbai", area: "Nerul, Navi Mumbai" },
  { id: "terna_nerul", name: "Terna Engineering College (Nerul)", shortName: "Terna Engg Nerul", zone: "Navi Mumbai Hub", lat: 19.0340, lng: 73.0200, city: "Navi Mumbai", area: "Nerul, Navi Mumbai" },
  { id: "bvcoe_kharghar", name: "Bharati Vidyapeeth College of Engineering - BVCOE (Kharghar)", shortName: "BVCOE Kharghar", zone: "Navi Mumbai Hub", lat: 19.0250, lng: 73.0560, city: "Navi Mumbai", area: "Kharghar, Navi Mumbai" },
  { id: "scoe_kharghar", name: "Saraswati College of Engineering - SCOE (Kharghar)", shortName: "Saraswati Kharghar", zone: "Navi Mumbai Hub", lat: 19.0480, lng: 73.0720, city: "Navi Mumbai", area: "Kharghar, Navi Mumbai" },
  { id: "pillai_panvel", name: "Pillai College of Engineering - PCE (New Panvel)", shortName: "Pillai Panvel", zone: "Navi Mumbai Hub", lat: 18.9902, lng: 73.1277, city: "Navi Mumbai", area: "New Panvel, Navi Mumbai" },
  { id: "dmce_airoli", name: "Datta Meghe College of Engineering - DMCE (Airoli)", shortName: "DMCE Airoli", zone: "Navi Mumbai Hub", lat: 19.1585, lng: 72.9980, city: "Navi Mumbai", area: "Airoli, Navi Mumbai" },
  { id: "ltce_koparkhairane", name: "Lokmanya Tilak College of Engineering - LTCE (Koparkhairane)", shortName: "LTCE Koparkhairane", zone: "Navi Mumbai Hub", lat: 19.1060, lng: 73.0110, city: "Navi Mumbai", area: "Koparkhairane, Navi Mumbai" },
  { id: "aiktc_panvel", name: "Anjuman-I-Islam's Kalsekar Technical Campus - AIKTC (Panvel)", shortName: "AIKTC Panvel", zone: "Navi Mumbai Hub", lat: 18.9985, lng: 73.1420, city: "Navi Mumbai", area: "New Panvel, Navi Mumbai" },

  // --- Zone 7: Thane & Extended Suburbs ---
  { id: "apsit_thane", name: "A.P. Shah Institute of Technology - APSIT (Thane West)", shortName: "APSIT Thane", zone: "Thane & Extended Suburbs", lat: 19.2680, lng: 72.9680, city: "Thane", area: "Ghodbunder Rd, Thane West" },
  { id: "kc_coe_thane", name: "K.C. College of Engineering & Management Studies (Thane East)", shortName: "KC College Thane", zone: "Thane & Extended Suburbs", lat: 19.1820, lng: 72.9810, city: "Thane", area: "Kopri, Thane East" },
  { id: "vcet_vasai", name: "Vidyavardhini's College of Engineering & Tech - VCET (Vasai Road)", shortName: "VCET Vasai", zone: "Thane & Extended Suburbs", lat: 19.3830, lng: 72.8280, city: "Palghar / Vasai", area: "Vasai Road West" },
  { id: "universal_vasai", name: "Universal College of Engineering (Vasai / Kaman)", shortName: "Universal Vasai", zone: "Thane & Extended Suburbs", lat: 19.3450, lng: 72.9350, city: "Palghar / Vasai", area: "Kaman, Vasai" },
  { id: "jondhale_dombivli", name: "Shivajirao S. Jondhale College of Engineering (Dombivli)", shortName: "Jondhale Dombivli", zone: "Thane & Extended Suburbs", lat: 19.2230, lng: 73.0880, city: "Kalyan / Dombivli", area: "Dombivli East" }
];

// Read request body helper
function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
      if (body.length > 2e6) { // 2MB limit
        reject(new Error('Body too large'));
      }
    });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (e) {
        reject(e);
      }
    });
    req.on('error', reject);
  });
}

// Request Handler
const server = http.createServer(async (req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  const method = req.method.toUpperCase();

  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  // ==========================================
  // API ROUTING
  // ==========================================

  // GET /api/hostels (Matching hostelmatch.onrender.com/api/hostels format)
  if (pathname === '/api/hostels' && method === 'GET') {
    const hostels = readHostelsData();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ results: hostels, count: hostels.length }));
    return;
  }

  // GET /api/colleges
  if (pathname === '/api/colleges' && method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ results: COLLEGES }));
    return;
  }

  // POST /api/hostels - Add Listing
  if (pathname === '/api/hostels' && method === 'POST') {
    try {
      const newListing = await parseBody(req);
      const hostels = readHostelsData();
      
      newListing.id = Date.now();
      newListing.verified = newListing.verified ?? true;
      newListing.verification_date = newListing.verification_date || new Date().toISOString().split('T')[0];
      
      hostels.unshift(newListing);
      writeHostelsData(hostels);

      res.writeHead(201, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true, hostel: newListing }));
    } catch (err) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: err.message }));
    }
    return;
  }

  // PUT /api/hostels/:id - Edit Listing
  const editMatch = pathname.match(/^\/api\/hostels\/(\d+)$/);
  if (editMatch && method === 'PUT') {
    try {
      const id = parseInt(editMatch[1]);
      const updatedData = await parseBody(req);
      const hostels = readHostelsData();
      const index = hostels.findIndex(h => h.id === id);

      if (index === -1) {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Hostel not found' }));
        return;
      }

      hostels[index] = { ...hostels[index], ...updatedData, id };
      writeHostelsData(hostels);

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true, hostel: hostels[index] }));
    } catch (err) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: err.message }));
    }
    return;
  }

  // DELETE /api/hostels/:id - Remove Listing
  if (editMatch && method === 'DELETE') {
    const id = parseInt(editMatch[1]);
    let hostels = readHostelsData();
    const initialLen = hostels.length;
    hostels = hostels.filter(h => h.id !== id);

    if (hostels.length === initialLen) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Hostel not found' }));
      return;
    }

    writeHostelsData(hostels);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ success: true, deletedId: id }));
    return;
  }

  // ==========================================
  // STATIC FILE ROUTING
  // ==========================================
  let filePath;
  if (pathname === '/' || pathname === '/admin') {
    filePath = path.join(PUBLIC_DIR, 'index.html');
  } else {
    filePath = path.join(PUBLIC_DIR, pathname);
  }

  // Prevent directory traversal attacks
  const safePath = path.resolve(filePath);
  if (!safePath.startsWith(path.resolve(PUBLIC_DIR))) {
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    res.end('Access Denied');
    return;
  }

  fs.stat(safePath, (err, stats) => {
    if (err || !stats.isFile()) {
      // Fallback: if not found, serve index.html for client SPA
      const indexPath = path.join(PUBLIC_DIR, 'index.html');
      fs.readFile(indexPath, (readErr, content) => {
        if (readErr) {
          res.writeHead(404, { 'Content-Type': 'text/plain' });
          res.end('404 Not Found');
        } else {
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
          res.end(content);
        }
      });
      return;
    }

    const ext = path.extname(safePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    fs.readFile(safePath, (readErr, content) => {
      if (readErr) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('Internal Server Error');
      } else {
        res.writeHead(200, { 'Content-Type': contentType });
        res.end(content);
      }
    });
  });
});

server.listen(PORT, () => {
  console.log(`=======================================================`);
  console.log(`🏠 HostelMatch Live Server running at: http://localhost:${PORT}`);
  console.log(`🔍 Main Discovery App: http://localhost:${PORT}/`);
  console.log(`⚙️ Admin Dashboard:    http://localhost:${PORT}/admin`);
  console.log(`📡 Backend API:        http://localhost:${PORT}/api/hostels`);
  console.log(`=======================================================`);
});
