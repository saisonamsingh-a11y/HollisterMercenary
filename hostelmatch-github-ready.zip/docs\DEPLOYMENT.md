# HostelMatch Deployment Guide

## Local Development
1. Clone the repository or navigate to project directory:
   ```bash
   cd C:\Users\Sai Sona\.gemini\antigravity\scratch\hostelmatch
   ```
2. Activate Virtual Environment & Install Dependencies:
   ```bash
   .\venv\Scripts\python -m pip install -r requirements.txt
   ```
3. Run the development server:
   ```bash
   .\venv\Scripts\python app.py
   ```
   Open `http://127.0.0.1:5000` in your browser.

4. Admin Dashboard:
   Navigate to `http://127.0.0.1:5000/admin`. Default Admin Key: `change-me`.

5. Run Automated Tests:
   ```bash
   .\venv\Scripts\python -m pytest test_app.py
   ```

## Production Deployment

### Option A: Render
1. Push your repository to GitHub / GitLab.
2. Connect your repo to Render.com.
3. Render automatically picks up `render.yaml` and deploys using `gunicorn app:app`.

### Option B: VPS (Gunicorn + Nginx)
1. Install Python 3 and dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run Gunicorn service:
   ```bash
   gunicorn --workers 4 --bind 127.0.0.1:5000 app:app
   ```
3. Reverse proxy with Nginx to forward port 80/443 to `127.0.0.1:5000`.

## Environment Variables
- `DB_PATH`: Path to SQLite database file (default: `hostelmatch.db`).
- `ADMIN_KEY`: Key required for Admin API & CRUD operations (default: `change-me`).
- `CAMPUS_LAT`: Latitude of university/college campus (default: `19.0760`).
- `CAMPUS_LNG`: Longitude of university/college campus (default: `72.8777`).
- `PORT`: HTTP port (default: `5000`).
