@echo off
echo ========================================================
echo   Starting HostelMatch Campus Housing Platform...
echo ========================================================

cd /d "%~dp0"

where node >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo [OK] Node.js detected. Launching Node server...
    start http://localhost:3000
    node server.js
    goto :end
)

where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo [OK] Python detected. Launching Python server...
    start http://localhost:3000
    python server.py
    goto :end
)

echo [INFO] Neither Node.js nor Python detected in PATH.
echo Opening index.html directly in your default browser...
start index.html

:end
pause
