import os, sys

# Add parent project root directory to path for app import
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import app

# Export WSGI application for Vercel Serverless Function handler
app = app
